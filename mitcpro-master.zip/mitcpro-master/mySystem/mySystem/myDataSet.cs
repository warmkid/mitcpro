﻿namespace mySystem {
    
    
    public partial class myDataSet {
    }
}
namespace mySystem {
    
    
    public partial class myDataSet {
    }
}
